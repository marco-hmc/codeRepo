#### C中如何调用C++函数？并重写类内成员函数声明
[c中如何调用C++函数](https://blog.csdn.net/nizqsut/article/details/52148973)<br>
[综合C调用C++，C++调用C](https://www.cnblogs.com/ruili07/p/9728389.html)