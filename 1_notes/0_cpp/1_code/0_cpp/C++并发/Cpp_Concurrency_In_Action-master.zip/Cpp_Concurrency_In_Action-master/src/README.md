# C++ Concurrency in Action

The source code of the Book [C++ Concurrency in Action](http://www.manning.com/williams/)
by Anthony Williams imported from the [ZIP Archive](http://www.manning.com/williams/CCiA_SourceCode.zip).
