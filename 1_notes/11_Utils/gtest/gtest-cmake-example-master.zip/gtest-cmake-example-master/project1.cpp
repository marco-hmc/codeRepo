#include "project1.h"

void Project1::foo(int &i) {
	i = 1;
}


void independentMethod(int &i) {
	i = 0;
}